# Copyright (C) 2019 SignalFx, Inc. All rights reserved.

name = 'signalfx_serverless_lambda'
version = '0.0.1'

user_agent = 'signalfx_serverless/' + version
packages = ['signalfx_lambda', 'signalfx_lambda.serverless']
