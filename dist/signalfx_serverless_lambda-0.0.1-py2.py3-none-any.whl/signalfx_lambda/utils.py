# Copyright (C) 2019 SignalFx, Inc. All rights reserved.

import os
import warnings

from .version import name, version

dim_prefix = 'lambda'

def get_fields():
    fields = {}

    return fields